import 'package:chatify_final_project/services/onboarding_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:firebase_messaging/firebase_messaging.dart'; // ← NEW
import 'package:chatify_final_project/app/routes.dart';
import 'package:chatify_final_project/app/theme.dart';
import 'package:chatify_final_project/app/bindings/initial_binding.dart';
import 'package:chatify_final_project/services/firebase_service.dart';
import 'package:chatify_final_project/services/notification_service.dart';
import 'package:get_storage/get_storage.dart'; // ← NEW (your notification service)

// This MUST be a top-level function (outside any class)
// Required for background/terminated notifications
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Initialize Firebase in background isolate
  await FirebaseService().init(); // Re-use your existing init logic
  if (kDebugMode) {
    print("Background message received: ${message.messageId}");
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    final firebaseService = FirebaseService();
    await firebaseService.init();
    if (kDebugMode) {
      print('✓ Firebase initialized successfully');
    }

    // ← NEW: Set the background handler
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

    // ← NEW: Initialize notifications (permissions, channels, listeners)
    await NotificationService.initialize();

  } catch (e) {
    if (kDebugMode) {
      print('✗ Firebase or Notification initialization failed: $e');
    }
    // Continue anyway
  }

  await GetStorage.init();

  final onboardingService = OnboardingService();
  final hasCompleted = await onboardingService.hasCompletedOnboarding();

  runApp(MyApp(showOnboarding: !hasCompleted));
}


class MyApp extends StatelessWidget {
  final bool showOnboarding;

  const MyApp({required this.showOnboarding, super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Chatify',
      initialBinding: InitialBinding(),
      getPages: AppRoutes.pages,
      initialRoute: AppRoutes.splash,
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
    );
  }
}