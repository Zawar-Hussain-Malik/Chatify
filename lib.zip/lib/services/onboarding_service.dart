import 'package:get_storage/get_storage.dart';

class OnboardingService {
  static const String _onboardingKey = 'onboarding_completed';
  final _storage = GetStorage();

  Future<bool> hasCompletedOnboarding() async {
    return _storage.read(_onboardingKey) ?? false;
  }

  Future<void> completeOnboarding() async {
    await _storage.write(_onboardingKey, true);
  }

  Future<void> resetOnboarding() async {
    await _storage.remove(_onboardingKey);
  }
}
