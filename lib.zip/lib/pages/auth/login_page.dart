import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:chatify_final_project/app/routes.dart';
import 'package:chatify_final_project/services/auth_service.dart';
import 'package:chatify_final_project/app/theme.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late TextEditingController emailCtrl;
  late TextEditingController passCtrl;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    emailCtrl = TextEditingController();
    passCtrl = TextEditingController();
  }

  @override
  void dispose() {
    emailCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = Get.find<AuthService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Sign In')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: emailCtrl,
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
              enabled: !isLoading,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: passCtrl,
              decoration: const InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
              enabled: !isLoading,
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: isLoading
                  ? null
                  : () async {
                if (emailCtrl.text.isEmpty || passCtrl.text.isEmpty) {
                  Get.snackbar(
                    'Validation Error',
                    'Please fill in all fields',
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.red,
                    colorText: Colors.white,
                  );
                  return;
                }

                if (!mounted) return;
                setState(() => isLoading = true);

                try {
                  final email = emailCtrl.text.trim();
                  final password = passCtrl.text;

                  print('Attempting login with: $email');

                  await auth.signInWithEmail(email, password);

                  print('Login successful');

                  if (mounted) {
                    Get.offNamed(AppRoutes.chats);
                  }
                } catch (e) {
                  print('Login error: $e');

                  if (mounted) {
                    Get.snackbar(
                      'Sign in failed',
                      e.toString(),
                      snackPosition: SnackPosition.BOTTOM,
                      backgroundColor: Colors.red,
                      colorText: Colors.white,
                      duration: const Duration(seconds: 3),
                    );
                  }
                } finally {
                  if (mounted) {
                    setState(() => isLoading = false);
                  }
                }
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(14)),
                  gradient: isLoading
                      ? LinearGradient(
                    colors: [
                      AppColors.gradientStart.withOpacity(0.5),
                      AppColors.gradientEnd.withOpacity(0.5),
                    ],
                  )
                      : const LinearGradient(
                    colors: [
                      AppColors.gradientStart,
                      AppColors.gradientEnd,
                    ],
                  ),
                ),
                child: Center(
                  child: isLoading
                      ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                      valueColor:
                      AlwaysStoppedAnimation<Color>(Colors.white),
                      strokeWidth: 2,
                    ),
                  )
                      : const Text(
                    'Sign in',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: isLoading ? null : () => Get.toNamed(AppRoutes.signup),
              child: const Text("Don't have an account? Sign up"),
            ),
          ],
        ),
      ),
    );
  }
}